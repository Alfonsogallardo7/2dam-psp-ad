package com.salesianostriana.dam.E07ManyToMany;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class E07ManyToManyApplicationTests {

	@Test
	void contextLoads() {
	}

}
