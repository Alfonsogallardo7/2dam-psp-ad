package com.salesianostriana.dam.E07ManyToMany;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class E07ManyToManyApplication {

	public static void main(String[] args) {
		SpringApplication.run(E07ManyToManyApplication.class, args);
	}

}
