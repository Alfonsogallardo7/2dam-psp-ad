package com.salesianostriana.dam.E07ManyToMany.services;

import com.salesianostriana.dam.E07ManyToMany.models.AddedTo;
import com.salesianostriana.dam.E07ManyToMany.repositories.AddedToRepository;
import com.salesianostriana.dam.E07ManyToMany.services.base.BaseService;
import org.springframework.stereotype.Service;

@Service
public class AddedToService extends BaseService<AddedTo, Long, AddedToRepository> {
}
